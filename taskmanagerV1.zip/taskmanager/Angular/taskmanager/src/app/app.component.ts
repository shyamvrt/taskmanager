import { Component } from '@angular/core';
import { FormGroup,FormControl,FormBuilder} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  
  test = new FormControl('');
  testTaskForm=new FormGroup({
    task: new FormControl('task1')
  });

  // constructor(builder: FormBuilder) {
  //   this.testTaskForm = builder.group({
  //     task: 'ttt'
  //   })
  // }

 
}
