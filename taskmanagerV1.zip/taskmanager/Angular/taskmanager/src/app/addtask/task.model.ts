export interface Task {
 task: string;
 priority: number;
 patrentTask: string;
 startDate: string;
 endDate: string;   
}