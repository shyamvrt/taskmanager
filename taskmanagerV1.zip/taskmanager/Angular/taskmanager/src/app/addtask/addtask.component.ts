import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl} from '@angular/forms';


@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent {

  // private task : Task;

  // constructor(private fb:FormBuilder) { }
  // addTaskForm =this.fb.group({
  //   task:['Task1'],
  //   Priority:[''],
  //   parentTask:[''],
  //   startDate:[''],
  //   endDate:['']
  // })
   addTaskForm=new FormGroup({
     task: new FormControl('task1'),
     priority:new FormControl('15'),
     parentTask:new FormControl(''),
     startDate:new FormControl(''),
     endDate:new FormControl('')
  });


}
